import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class LoadTable extends LoadDataSava {

	private JFrame frame;
	static private JTable MYTABLE;
	static public String Data1[][];
	static public String [] ColumnNames1 = {"MesCyc_ID", "Mes_Press", "Mes_Diff", "Mes_Disch", "Mes_Vol"};
		

	/**
	 * Create the application.
	 */
	public LoadTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 549, 372);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
				
		Table(); //Initialize MYTABLE
		
		JButton Finish = new JButton("Finish and Menu");
		Finish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				LaunchWindow WL = new LaunchWindow();
			}
		});
		Finish.setBounds(205, 298, 137, 29);
		frame.getContentPane().add(Finish);
		
		if(Model.compareTo("0") == 0) {
			Model = "Conventional";
		} else {
			Model = "Novel";
		}
		
		JLabel Description = new JLabel(Date + " - " + Model + " - " + CycTime + " seconds" + " - Bot_ID: " + Bot_ID);
		Description.setBounds(80, 22, 368, 16);
		frame.getContentPane().add(Description);
		
		JScrollPane scrollPane = new JScrollPane(MYTABLE);
		scrollPane.setBounds(51, 64, 442, 222);
		frame.getContentPane().add(scrollPane);
		
		frame.setVisible(true);
		
	}
	/*
	 * This method opens the connection.     */
		private static void openConn() {  
	     try {
				
	         // Try to connect to the database
	         conn = DriverManager.getConnection("jdbc:sqlite:" + FILE); //Need to have JDBC driver referenced.
	         MESSAGE = "DB \"" + FILE + "\" selected.";
	         System.out.println(MESSAGE);
	     
	     } catch (SQLException EX) {
	         MESSAGE = "exception: " + EX;
	            
	     }  
	 }

	 /*
	 * This method closes the connection. It should be called by all methods who open a DB connection
	 */	
	 private static void closeConn() {   
	     try {
	         if (conn != null) conn.close();
	         
	     } catch (SQLException EX) {
	         if ((EX.getErrorCode() == 50000) && ("XJ015".equals(EX.getSQLState()))) {
	             System.out.println("SQLite shut down properly");
	             
	         } else {
	             System.err.println("SQLite did not shut down properly");
	             System.err.println(EX.getMessage());
	             
	         }
	         
	     }
	             
	 }
	

	public static void Table() {
		
		openConn();
		
		try{
	    	 Statement stmt;  
	    	 Statement stmt1;
	         ResultSet rs = null;
	         ResultSet rowNum = null;

	         String strSQL = "";
	         
	         // Select all from the bottle with the Date in front
	         strSQL = "SELECT MesCyc_ID, Mes_Press, Mes_Diff, Mes_Disch, Mes_Vol "
	         		+ " FROM tMeasurements "
	         		+ " WHERE MesBot_ID = " + Bot_ID //Using the Bot_ID that was stored from the user parameter. 
	         		+ " ORDER BY MesBot_ID ASC;";
	         
	         stmt = conn.createStatement();
	         rs = stmt.executeQuery(strSQL); //ResultSet that stores executed script 
	         
	         //For the Number of rows for the 2D array
	         String strSQL1 = "SELECT COUNT(*) FROM tMeasurements WHERE MesBot_ID = " + Bot_ID;  
	         stmt1 = conn.createStatement();
	         rowNum = stmt1.executeQuery(strSQL1);
	        
	 		 //Get the number of rows to initialize array with right number of rows
			 Data1 = new String[(((Number) rowNum.getObject(1)).intValue())][5];

	         
	         int c = 0; //Loop through the ResultSet in order to store the measurements in the 2D array to create the MYTABLE
	         while (rs.next()) { //While the resultSet has more items.

	              Data1[c][0] = rs.getString(ColumnNames1[0]);
	              Data1[c][1] = rs.getString(ColumnNames1[1]);
	              Data1[c][2] = rs.getString(ColumnNames1[2]);
	              Data1[c][3] = rs.getString(ColumnNames1[3]);
	              Data1[c][4] = rs.getString(ColumnNames1[4]);

	              c++;
	         }	         	

		} catch (SQLException e){
				System.out.println("Error: " + e.getMessage());
		}
  	

		
	  	closeConn();

		MYTABLE = new JTable(new MyTableModel(Data1, ColumnNames1));
		MYTABLE.setCellSelectionEnabled(true);
		MYTABLE.setBackground(Color.pink);
		MYTABLE.getTableHeader().setReorderingAllowed(false);

		ExcelAdapter myAd = new ExcelAdapter(MYTABLE); //https://www.infoworld.com/article/2077579/java-tip-77--enable-copy-and-paste-functionality-between-swing-s-jMYTABLEs-and-excel.html
		MYTABLE.setBounds(70, 50, 422, 226);
				
	}
}




