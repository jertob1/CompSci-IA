import java.awt.EventQueue;


import java.awt.event.ItemEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

//For database
//For database connection
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
//import java.sql.Driver;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.Font;

public class SaveData extends GatherDataMenu {

	static JFrame SD;
	static JComboBox comboBox;
	private JTextField textFieldDatabase;
	
	static String Model = "0";
	static String CycTime = "";
	static String Date =  "";
	
	//Variables for database
    static String MESSAGE;
    static Connection conn = null; //Sqlite data type for connections
	static String FILE;
	
    static int ID = 0;
    
	/**
	 * Create the application.
	 */
	public SaveData() {
		initialize();
	}

	/**
	 * Initialize the contents of the SD.
	 */
	private void initialize() {
		
		GDM.dispose();
		SD = new JFrame();
		SD.setBounds(100, 100, 299, 394);
		SD.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SD.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Save Data");
		lblNewLabel.setFont(new Font("Lucida Grande", Font.PLAIN, 26));
		lblNewLabel.setBounds(85, 19, 132, 37);
		SD.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Fill these required fields");
		lblNewLabel_1.setBounds(29, 68, 162, 16);
		SD.getContentPane().add(lblNewLabel_1);
		
		JRadioButton Conventional = new JRadioButton("Conventional Valve");
		Conventional.setBounds(50, 86, 162, 23);
		SD.getContentPane().add(Conventional);
		
		JRadioButton Novel = new JRadioButton("Novel Valve");
		Novel.setBounds(50, 111, 141, 23);
		SD.getContentPane().add(Novel);
		
		ButtonGroup bg = new ButtonGroup();    
		bg.add(Conventional); bg.add(Novel);  
		
		String num[] = {"1", "2" , "3", "4", "5", "6", "7", "8", "9", "10"};
		comboBox = new JComboBox(num);
		comboBox.setBounds(51, 179, 72, 27);
		SD.getContentPane().add(comboBox);
		
		JLabel lblNewLabel_1_1 = new JLabel("Select Cycle Time");
		lblNewLabel_1_1.setBounds(29, 151, 162, 16);
		SD.getContentPane().add(lblNewLabel_1_1);
		
		JRadioButton CreateTable = new JRadioButton("Create Table now");
		CreateTable.setBounds(29, 290, 162, 23);
		SD.getContentPane().add(CreateTable);
		
		textFieldDatabase = new JTextField();
		textFieldDatabase.setColumns(10);
		textFieldDatabase.setBounds(50, 252, 130, 26);
		SD.getContentPane().add(textFieldDatabase);

		JButton btnNewButton = new JButton("Finish"); //Button cannot be on until all of the fields are filled.
		
		btnNewButton.setEnabled(false);
		textFieldDatabase.addKeyListener(new KeyAdapter() { //Key listener to check whether all required fields are compeleted
	        public void keyReleased(KeyEvent e) {
	            super.keyReleased(e);
	            
	    		if(bg.getSelection() == null && textFieldDatabase.getText().length() == 0) {
	    			btnNewButton.setEnabled(false);
	    		}else {
	    			btnNewButton.setEnabled(true);

	    		}
	        }
	    });
		
		
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		
				//Checks which button of the radioButton is checked
				if (Conventional.isSelected()) Model = "0";
				if (Novel.isSelected()) Model = "1";
				
				CycTime = comboBox.getSelectedItem().toString(); //Get ComboBox chosen number number			
				FILE = textFieldDatabase.getText(); //Get name of the Database
				
				SelectDatabase();
				SendData();
				

				if(CreateTable.isSelected()) {
					SD.setVisible(false);
					CreateTable newTable = new CreateTable();

				} else { 
					SD.dispose();
					GDM.dispose();
					MainWindow ms = new MainWindow();
					
				}

			}
		});
		btnNewButton.setBounds(85, 325, 117, 29);
		SD.getContentPane().add(btnNewButton);
		
		JLabel NameDatabase = new JLabel("Enter the name of the database");
		NameDatabase.setBounds(29, 234, 206, 16);
		SD.getContentPane().add(NameDatabase);


		SD.setVisible(true);
	}
	
    
	private static void openConn() {  //Need to have JDBC driver referenced.
       
		try {	
            //Connect to the database
        	//FILE refers to the variable that stores the name of the database inputted by user
            conn = DriverManager.getConnection("jdbc:sqlite:" + FILE); //Stores the connection created in 'conn'
            														  //Connection is created in the same directory as the Java project
            MESSAGE = "DB \"" + FILE + "\" selected.";
        
        } catch (SQLException EX) {
            MESSAGE = "exception: " + EX; //Catch an error
        	JFrame f = new JFrame();
        	JOptionPane.showMessageDialog(f, "ERROR: try again"); //Error message
            SaveData sd = new SaveData(); //Create a new instance 
               
        }  
    }

    /*
    * This method closes the connection. It should be called by all methods who open a DB connection
    */
    private static void closeConn() {   
        try {
            if (conn != null) conn.close(); //If a conn has been created then close the conn
            
        } catch (SQLException EX) { //If SQL catches an error 
            if ((EX.getErrorCode() == 50000) && ("XJ015".equals(EX.getSQLState()))) {
                System.out.println("SQLite shut down properly");
                
            } else {
                System.err.println("SQLite did not shut down properly");
                System.err.println(EX.getMessage());
                closeConn(); //Call the method again to shut down the connection

            }
            
        }
                
    }
    
    private static void SelectDatabase() {
        
    	Statement stmt; //Variable that is used to execute SQL statement
        String strSQL = ""; //Variable to write the SQL statement in String

		openConn(); //Open connection to current database

        // Open connection to current DB
        System.out.println(MESSAGE);
        
        // Try to create the table "tBottle" IF it doesn't already exist
        try{
            stmt = conn.createStatement();
            strSQL = "CREATE TABLE IF NOT EXISTS tBottle ("
					+ "Bot_ID INTEGER PRIMARY KEY AUTOINCREMENT,"
					+" Bot_Model INTEGER NOT NULL, Bot_CycTime INTEGER NOT NULL, Bot_Date TEXT NOT NULL);";            
            stmt.execute(strSQL);
            System.out.println("Table tBottle is ready");

        } catch (SQLException EX) {
            System.out.println(EX.getMessage());
        
        }

        // Try to create the table "tCycles" IF it doesn't already exist
        try{
            stmt = conn.createStatement();
            strSQL = "CREATE TABLE IF NOT EXISTS tCycle ("
            + " Cycle_ID integer PRIMARY KEY AUTOINCREMENT,"
            + " Cycle_Description Text);";
            stmt.execute(strSQL);
            System.out.println("Table tCycle is ready");
            
        	//Send tCycle
        	final String sqlCyc = "INSERT INTO tCycle VALUES(?,?)"; //Prepare statemnt	
        		for(int c = 1; c <= 50; c++){

        				PreparedStatement pstmt = conn.prepareStatement(sqlCyc); //An object that represents a precompiled SQL statement

        				pstmt.setInt(1, c);
        				pstmt.setString(2, null);
        				pstmt.executeUpdate();
        				pstmt.close();   
        		} 
        			         
        } catch (SQLException EX) {
            System.out.println(EX.getMessage());
        }
        
        // Try to create the table "tMeasurements" IF it doesn't already exist
        try{
            stmt = conn.createStatement();
            strSQL = "CREATE TABLE IF NOT EXISTS tMeasurements(" 
            + " Mes_ID integer PRIMARY KEY AUTOINCREMENT," //Create the primary key column
            + " Mes_Press Real not null, Mes_Diff Real not null, Mes_Disch Real not null, Mes_Vol Real not null," //Create needed tables with datatype
            + " MesBot_ID integer not null, MesCyc_ID integer not null," //Create tables that will be used for foreign keys
            + " FOREIGN KEY(MesBot_ID) REFERENCES tBottle(Bot_ID)," //Create a reference to foreign keys
            + " FOREIGN KEY(MesCyc_ID) REFERENCES tCycle(Cycle_ID));"; //Create a reference to foreign keys

            stmt.execute(strSQL); //execute the SQLite statement
            System.out.println("Table tMeasurements is ready"); //feeback
                     
        } catch (SQLException EX) {
            System.out.println(EX.getMessage());
        
        } finally {
        	// Close the connection to database
        	closeConn();
        }

    }
   
    public static void SendData() {

    	openConn();
    	//SEND tBOTTLE
    	final String sqlBot = "INSERT INTO tBottle VALUES(?,?,?, date('now', 'localtime'))"; //Prepare statemnt
    		try{
    				PreparedStatement pstmt = conn.prepareStatement(sqlBot); //An object that represents a precompiled SQL statement

    				pstmt.setString(1, null); //Can send as string and will be checked as REAL in the database
    				pstmt.setString(2, Model);
    				pstmt.setString(3, CycTime);
    				pstmt.executeUpdate();
    				pstmt.close();   
    		} 
    			
    		catch (SQLException e){
    				System.out.println("Error: " + e.getMessage());
    		}
    	
    	closeConn();
    	openConn();
    	//Insert measurements into tMeasurements
    	String sqlMeas = "INSERT INTO tMeasurements VALUES(?,?,?,?,?,?,?)"; //Initialize a sql prepare statemnt
    	
    	try{
	    	 Statement stmt;
	         ResultSet rs = null;
	         String strSQL1 = "";
	         System.out.println("Query done");
	         
	         strSQL1 = "SELECT Bot_ID " //This SQL script will retrieve the ID of the bottle that was just created.  
	         		+ "FROM tBottle "
	         		+ "WHERE Bot_ID = (SELECT MAX(Bot_ID) FROM tBottle)";
	         stmt = conn.createStatement();
	         rs = stmt.executeQuery(strSQL1); //RS with the executed query 

	         if (rs.next()) { //retrieve the ID from the resultset 
	             ID = rs.getInt("Bot_ID");
	         }
	         	         	    	
	    	 for(int c = 0; c < CounterCycle; c++){ //Loop to Insert measurements stored in arrays in the database
    		
    				PreparedStatement pstmt = conn.prepareStatement(sqlMeas); //An object that represents a precompiled SQL statement
    			
    				//The integer in the arguments of 'setString' refers to the index of the question mark in the prepared statement
    				
    				pstmt.setString(1, null);     //Data is sent as string and translated to REAL according to the datatype of the columns in the database
    				pstmt.setString(2, SPress[c]); //Pressure 
    				pstmt.setString(3, SDi[c]);//Differential pressure
    				pstmt.setString(4, SDi[c]);//Discharge rate
    				pstmt.setString(5, SVo[c]);//Volume
    				pstmt.setInt(6, ID); //BotID
    				pstmt.setInt(7, c+1); //Cycle#

    				pstmt.executeUpdate(); //Execute statement
    				pstmt.close(); //close statement to recreate one for each iteration
    		} 
    			

    	} catch (SQLException e){
				System.out.println("Error: " + e.getMessage());
		}
    	
    	closeConn();
    }
}
