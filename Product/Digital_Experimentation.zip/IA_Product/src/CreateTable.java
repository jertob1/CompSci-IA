import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.KeyStroke;
import javax.swing.JButton;
import javax.swing.JComponent;

import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JScrollPane;

public class CreateTable extends SaveData {

	private static JFrame frame;
	static private JTable table;

	/**
	 * Create the application.
	 */
	public CreateTable() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		SD.dispose();
		frame = new JFrame();
		frame.setBounds(100, 100, 549, 372);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		Table(); //Initialize table
		
		JButton Finish = new JButton("Finish and Menu");
		Finish.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame.dispose();
				LaunchWindow LKW = new LaunchWindow();
			}
		});
		Finish.setBounds(205, 298, 137, 29);
		frame.getContentPane().add(Finish);
		
		if(Model.compareTo("0") == 0) {
			Model = "Conventional";
		} else {
			Model = "Novel";
		}
		
		JLabel Description = new JLabel(Model + " - " + CycTime + " seconds" + " - Bot_ID: " + ID);
		Description.setBounds(175, 23, 368, 16);
		frame.getContentPane().add(Description);
		
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setBounds(51, 64, 442, 222);
		frame.getContentPane().add(scrollPane);
		
		frame.setVisible(true);
		
	}
	
	public static void Table() {
		
		String [] ColumnNames = {"Cyc_ID", "Pressure", "Differential", "Discharge rate", "Volume"}; //String array for the names of the columns
		String Data [][] = new String[CounterCycle][5]; //2D array that stores the Data used to create the JTable
														//CounterCycle is the amount of cycles, hence measurements, for a specific bottle
														//initialize the array with 5 column because there are 5 different variable that are displayed.
		
		for(int c = 0; c < CounterCycle; c++) { //Loop to put data in 2D array
			
			Data[c][0] = Integer.toString(c + 1);
			Data[c][1] = SPress[c];
			Data[c][2] = SDi[c];
			Data[c][3] = SDi[c];
			Data[c][4] = SVo[c];
		}
		
		table = new JTable(new MyTableModel(Data, ColumnNames)); //Initialize JTable with a table model that makes cell not editable but selectable
		table.setCellSelectionEnabled(true);
		table.setBackground(Color.pink);
		ExcelAdapter myAd = new ExcelAdapter(table); //Class that enables copy and paste for the table
		table.setBounds(70, 50, 422, 226);
				
	}

}
