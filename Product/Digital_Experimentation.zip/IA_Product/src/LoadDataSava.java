import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.JButton;

public class LoadDataSava {

	private JFrame frame; 
	static boolean showRest = false;
	static private JTable TempTable;
	
	//For Database SQL
	static String CMD = null;
    static String[] ARG;      
    static String curDB;
    static String MESSAGE;
    static Connection conn = null;
	static String FILE;
	private JTextField textFieldDatabase;
	
	String row = "";
	static int response = 1;
	
	//For Table
	static String Table[][];
	static String[] ColumnNames = new String[4];
	
	static String Parameter = ""; //Search Parameter
	static int selectedRow;
	static int column;
	
	static public String Bot_ID;
	static public String Model;
	static public String Date;
	static public String CycTime;


	public LoadDataSava() { //Constructor 
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 669, 484);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Load Data");
		lblNewLabel.setBounds(300, 23, 69, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Search by");
		lblNewLabel_1.setBounds(208, 87, 69, 16);
		
		JButton btnCreate = new JButton("Create Table"); //IF button pressed, get the *Bot_ID* and the tBottle to create table based on that.
		btnCreate.setBounds(33, 408, 117, 29);
		btnCreate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnCreate) {
					column = TempTable.getColumnModel().getColumnIndex("Bot_ID");
					Bot_ID = TempTable.getValueAt(selectedRow, column).toString(); //Get Bot_ID
					
					column = TempTable.getColumnModel().getColumnIndex("Bot_Date");
					Date = TempTable.getValueAt(selectedRow, column).toString(); //Get Bot_Date
					
					column = TempTable.getColumnModel().getColumnIndex("Bot_CycTime");
					CycTime = TempTable.getValueAt(selectedRow, column).toString(); //Get Bot_CycTime
					
					column = TempTable.getColumnModel().getColumnIndex("Bot_Model");
					Model = TempTable.getValueAt(selectedRow, column).toString(); //Get Bot_Model
					
					frame.dispose();
					LoadTable LT = new LoadTable();
				}
			}
		});
		
		String num[] = {"None", "Date", "Bot_ID" , "Bot_Model", "Bot_CycTime"};
		JComboBox comboSearch = new JComboBox(num);
		comboSearch.setBounds(281, 83, 105, 27);
		
		//Button to open database
		JButton btnOpenDatabase = new JButton("Select Database");
		btnOpenDatabase.setBounds(265, 42, 139, 29);
		frame.getContentPane().add(btnOpenDatabase);
		
		btnOpenDatabase.addActionListener(new ActionListener() { //Action listener for database button
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()==btnOpenDatabase) {
					
					//Using a JFile chooser to choose the DATABASE 
					JFileChooser FC = new JFileChooser(); //Open file chooser
					FC.setCurrentDirectory(new File("."));
					response = FC.showOpenDialog(null); //variable to check the responde of the file chooser
					
					if(response == JFileChooser.APPROVE_OPTION) { //If the approve option has been selected
						FILE = FC.getSelectedFile().getName();  //Store the name of the file selected 
						
						JFrame f = new JFrame();
			        	JOptionPane.showMessageDialog(f, "Database Selected: " + FILE);	//Option Pane to say that Database was selected.
						
						frame.getContentPane().add(comboSearch);  //When Database has been selected, other elements are placed on the GUI
						frame.getContentPane().add(lblNewLabel_1);
						frame.getContentPane().add(btnCreate);
						
					}
					btnOpenDatabase.setText(FILE); //The button now displaying the name of database selected.
				}
			}
		});

		ActionListener cbActionListener = new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
	
				Parameter = (String) comboSearch.getSelectedItem();	
				System.out.println(Parameter);

				Search();
				
				JScrollPane scrollPane = new JScrollPane(TempTable); //Create the scrollPane that is used for search parameter
				scrollPane.setBounds(75, 122, 519, 261);
				scrollPane.setVisible(true);
				frame.getContentPane().add(scrollPane);
				

				TempTable.addMouseListener(new MouseAdapter() { //Mouse listener to check the row that was clicked
					  public void mouseClicked(MouseEvent e) {
						  selectedRow = TempTable.getSelectedRow();
						  System.out.println(selectedRow);
					  }
					});

			}
		};
		comboSearch.addActionListener(cbActionListener);
		
		frame.setVisible(true);
		
	}
	
	/*
    * This method opens the connection.     */
	private static void openConn() {  
        try {
			
            // Try to connect to the database
            conn = DriverManager.getConnection("jdbc:sqlite:" + FILE); //Need to have JDBC driver referenced.
            MESSAGE = "DB \"" + FILE + "\" selected.";
            System.out.println(MESSAGE);
        
        } catch (SQLException EX) {
            MESSAGE = "exception: " + EX;
               
        }  
    }

    /*
    * This method closes the connection. It should be called by all methods who open a DB connection
    */	
    private static void closeConn() {   
        try {
            if (conn != null) conn.close();
            
        } catch (SQLException EX) {
            if ((EX.getErrorCode() == 50000) && ("XJ015".equals(EX.getSQLState()))) {
                System.out.println("SQLite shut down properly");
                
            } else {
                System.err.println("SQLite did not shut down properly");
                System.err.println(EX.getMessage());
                
            }
            
        }
                
    }

	public static void Search() {
		openConn();
		
		try{
	    	 Statement stmt;  
	    	 Statement stmt1;
	         ResultSet rs = null;
	         ResultSet rowNum = null;

	         String strSQL = "";
	         
	         if(Parameter.equals("Date")) {
	        	// Select all from the bottle with the Date as the reference column
		         strSQL = "SELECT Bot_Date, Bot_ID, Bot_Model, Bot_CycTime "
		         		+ " FROM tBottle"
		         		+ " ORDER BY Bot_Date ASC;";
		         
	         }else if(Parameter.equals("Bot_ID")) {
		        // Select all from the bottle with the Bot_ID as the reference column
		         strSQL = "SELECT Bot_ID, Bot_Date, Bot_Model, Bot_CycTime "
			         		+ " FROM tBottle"
			         		+ " ORDER BY Bot_ID ASC;";
		         
	         }else if(Parameter.equals("Bot_Model")){
		        	// Select all from the bottle with the Bot_Model as the reference column
	        	 strSQL = "SELECT  Bot_Model, Bot_ID, Bot_Date, Bot_CycTime "
			         		+ " FROM tBottle"
			         		+ " ORDER BY Bot_Model ASC;";
		         
	         }else if(Parameter.equals("Bot_CycTime")) {
	        	// Select all from the bottle with the Bot_CycTime as the reference column 
	        	 strSQL = "SELECT Bot_CycTime, Bot_ID, Bot_Date, Bot_Model "
			         		+ " FROM tBottle"
			         		+ " ORDER BY Bot_CycTime ASC;";
	         }
	        
	        
//	         switch(Parameter) { //Switch statement that selects the SQL script depending on the search paramenter of the user.
//	         					//Parameter is the option chosen from the comboBox
//	         	case("Date"): 
//			         // Select all from the bottle with the Date as the reference column
//			         strSQL = "SELECT Bot_Date, Bot_ID, Bot_Model, Bot_CycTime "
//			         		+ " FROM tBottle"
//			         		+ " ORDER BY Bot_Date ASC;";
//	
//		         case("Bot_ID"):
//		        	// Select all from the bottle with the Bot_ID as the reference column
//			         strSQL = "SELECT Bot_ID, Bot_Date, Bot_Model, Bot_CycTime "
//				         		+ " FROM tBottle"
//				         		+ " ORDER BY Bot_ID ASC;";
//			         
//		         case("Bot_Model"):
//		        	// Select all from the bottle with the Bot_Model as the reference column
//		        	 strSQL = "SELECT  Bot_Model, Bot_ID, Bot_Date, Bot_CycTime "
//				         		+ " FROM tBottle"
//				         		+ " ORDER BY Bot_Model ASC;";
//	
//		         case("Bot_CycTime"):
//		        	// Select all from the bottle with the Bot_CycTime as the reference column 
//		        	 strSQL = "SELECT Bot_CycTime, Bot_ID, Bot_Date, Bot_Model "
//				         		+ " FROM tBottle"
//				         		+ " ORDER BY Bot_CycTime ASC;";
//	         }
	         
	         stmt = conn.createStatement(); //Allign the statement with the SQLite connection
	         System.out.println(strSQL);
	         rs = stmt.executeQuery(strSQL); //Execute the query
	        	         
	         //Create a new query to store the number of rows in tBottle. This number will be used to initialize the number of rows in the table (2D array).
	         String strSQL1 = "SELECT COUNT(*) FROM tBottle";  
	         stmt1 = conn.createStatement();
	         rowNum = stmt1.executeQuery(strSQL1);

	         //Initialize 2D array for the table that will be used to search the needed bottle
	         Table = new String[(((Number) rowNum.getObject(1)).intValue())][4]; //Intialize array with correct numebr	 
	         
	         ResultSetMetaData rsmd = rs.getMetaData(); //Using a resultSetMetaData object that provides information about the columns in a ResultSet.

	         for(int c = 0; c < rsmd.getColumnCount(); c++) { //Looping throuhg rsmd to store the column names in the right order.
	              ColumnNames[c] = rsmd.getColumnName(c+1);   //Store in ColumnNames to create table.
	              System.out.println(ColumnNames[c]);
	         }
	         
	         int c = 0;   
	         while (rs.next()) {

	              Table[c][0] = rs.getString(ColumnNames[0]);
	              Table[c][1] = rs.getString(ColumnNames[1]);
	              Table[c][2] = rs.getString(ColumnNames[2]);
	              Table[c][3] = rs.getString(ColumnNames[3]);
	              c++;
	         }	         	

		} catch (SQLException e){
				System.out.println("Error: " + e.getMessage());
		}
   	
   	closeConn();
   	
   	//Create table
	TempTable = new JTable(Table, ColumnNames);
	TempTable.setVisible(true);
	TempTable.setCellSelectionEnabled(true);
	TempTable.setBackground(Color.pink);
	TempTable.getTableHeader().setReorderingAllowed(false);
	TempTable.setBounds(70, 50, 422, 226);

	}
}
