import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class LaunchWindow extends MainWindow {

	public static JFrame LW;
	
	/**
	 * Create the application.
	 */
	public LaunchWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the LW.
	 */
	private void initialize() {
		LW = new JFrame();
		LW.setBounds(100, 100, 450, 300);
		LW.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		LW.getContentPane().setLayout(null);
		
		JButton LoadTable = new JButton("Load Table"); //BUTTON TO LAUNCH LOAD TABLE MENU
		LoadTable.setForeground(new Color(248, 0, 7));
		LoadTable.addActionListener(new ActionListener() { //LoadTable Action Listener
			public void actionPerformed(ActionEvent e) {
				LW.dispose(); //Dispose the LW before creating a new instance
				LoadDataSava LD = new LoadDataSava(); //Create a new instance of the LoadDataSava class
			}
		});
		LoadTable.setBackground(new Color(99, 170, 255));
		LoadTable.setBounds(63, 108, 130, 41);
		LW.getContentPane().add(LoadTable); // Add to LW
		
		JButton GatherData = new JButton("Gather Data"); //BUTTON TO LAUNCH LOAD TABLE MENU
		GatherData.addActionListener(new ActionListener() { //GatherData Action Listener
			public void actionPerformed(ActionEvent e) {
				LW.dispose(); //Dispose the LW before creating a new instance
				GatherDataMenu ba = new GatherDataMenu(); //Create a new instance of the GatherDataMenu class
			}
		});
		
		
		GatherData.setBounds(248, 108, 130, 41);
		LW.getContentPane().add(GatherData); //Add to the LW
		
		JButton btnNewButton_2 = new JButton("help");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	        	JFrame f = new JFrame();
	        	JOptionPane.showMessageDialog(f, "This application was designed to provide a digital solution to measuring and storing data with sensors for an experiment"
	        			+ "\nMy client was a Master student who was conducting experiments for his Master Thesis project in chemical engineering"
	        			+ "\nPress Gather Data to start your experiments"
	        			+ "\nPress Load Table to create table from existing measurements");
	        									
			}
		});
		btnNewButton_2.setForeground(Color.BLUE);
		btnNewButton_2.setBounds(170, 211, 117, 29);
		LW.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("exit");
		btnNewButton_2_1.setForeground(Color.BLUE);
		btnNewButton_2_1.setBackground(Color.LIGHT_GRAY);
		btnNewButton_2_1.setBounds(170, 237, 117, 29);
		LW.getContentPane().add(btnNewButton_2_1);
		
		JLabel lblNewLabel = new JLabel("Welcome");
		lblNewLabel.setBounds(195, 49, 61, 16);
		LW.getContentPane().add(lblNewLabel);
		
		LW.setVisible(true);
		
	}

}
