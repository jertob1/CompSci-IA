import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.text.DefaultCaret;

import com.fazecast.jSerialComm.*; // Serial Port classes

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;

import java.awt.event.ActionListener;
import java.util.concurrent.TimeUnit;
import java.awt.event.ActionEvent;
import java.awt.Font;

public class GatherDataMenu extends Thread {

	static JFrame GDM;
	static JTextArea textArea = new JTextArea();
	static JButton ButStart = new JButton("Start"); //Button that starts the program
	static JButton ButNext = new JButton("Next"); //Button for next cycle
	static JButton ButEnd = new JButton("End"); //Button to end the program
	static JLabel lblNewLabel = new JLabel("Gather Data Menu");
	static JScrollPane taScroll;
	static SerialPort MySerialPort;
	
	static String S = "S"; //Variable for the transmission of data
	static boolean NextState = false;
	static boolean EndState = false;
	
	static String Results = ""; //Results of the bottle
	static int CounterCycle = 0;
	
	//Arrays to store values
	static String SPress[];
	static String SDi[];
	static String SVo[];

	/**
	 * Create the application.
	 */
	public GatherDataMenu() {
		initialize();
		
	}

	/**
	 * Initialize the contents of the GDM.
	 */
	private void initialize() {
		GDM = new JFrame();
		GDM.setBounds(100, 100, 635, 450);
		GDM.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		GDM.getContentPane().setLayout(null);
		textArea.setFont(new Font("SansSerif", Font.PLAIN, 13));
		
		textArea.setLineWrap(true);
		textArea.setBounds(40, 36, 528, 320);
		textArea.setEditable(false);
		DefaultCaret caret = (DefaultCaret)textArea.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		
		taScroll = new JScrollPane(textArea);
		taScroll.setBounds(40, 36, 528, 320);
		taScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		
		GDM.getContentPane().add(taScroll);
		
		ButStart.setBounds(53, 368, 117, 29);
		GDM.getContentPane().add(ButStart);
		
		ButNext.setBounds(265, 368, 117, 29);
		ButNext.setEnabled(false);
		GDM.getContentPane().add(ButNext);

		ButEnd.setEnabled(false);
		ButEnd.setBounds(451, 368, 117, 29);
		GDM.getContentPane().add(ButEnd);
		
		lblNewLabel.setBounds(265, 18, 123, 16);
		GDM.getContentPane().add(lblNewLabel);
		
		ButStart.addActionListener(new ActionListener() { //ActionListener for ButStart
			public void actionPerformed(ActionEvent e) {
				ButStart.setEnabled(false); //Turning off the ButStart, so that it cannot be pressed again
				new Thread(() -> {			//Creating a new thread
					InitializeTransmission();
					GetData();
				}).start();
			}
		});
		
		GDM.setVisible(true);
	}
	
	public static void InitializeTransmission() {
		
			ButStart.setEnabled(false); //Once Start has been pushed, it cannot be pushed again
			//Variables for the Reception
			int BaudRate = 9600;
			int DataBits = 8;
			int StopBits = SerialPort.ONE_STOP_BIT;
			int Parity   = SerialPort.NO_PARITY;
	
			SerialPort [] AvailablePorts = SerialPort.getCommPorts(); //Initializes the SerialPort array object and storing the available ports on the computer
			
	        //Open the first Available port
	        MySerialPort = AvailablePorts[AvailablePorts.length - 2]; //THIS IS ONLY SPECIFIC TO MY COMPUTER 
	        
	        // Set Serial port Parameters
	        MySerialPort.setComPortParameters(BaudRate,DataBits,StopBits,Parity);//Sets all serial port parameters at one time
	        MySerialPort.setComPortTimeouts(SerialPort.TIMEOUT_READ_BLOCKING, 1000, 0); //Set Read Time outs
	        MySerialPort.openPort(); //open the port
	
	        if (MySerialPort.isOpen()) { //If the Connection is open
	    		textArea.append("\nPORT:  " + MySerialPort.getSystemPortName() + " IS OPEN \n");
	        }else {
	   			textArea.append("  ");
	        	JFrame f = new JFrame();
	        	JOptionPane.showMessageDialog(f, "ERROR: Arduino is not connected");
        		GDM.dispose();
	        	GatherDataMenu LWD = new GatherDataMenu(); //Creates an new instance of the class if 
	        }
	        
	      	MySerialPort.flushIOBuffers();
	      	System.out.println("Initialization complete");     
	    	
	      	//After Initilaization is finished, I start the exchange of data between Java and Arduino.
			boolean ENDLOOP = true;
			try {

				while (ENDLOOP == true){
					
					NextState = false;
					EndState = false;
					
					byte[] readBuffer = new byte[200]; //Creates a byte object because bytes are read from the Serial monitor and then converted to strings
					int numRead = MySerialPort.readBytes(readBuffer, readBuffer.length); //Counts the number of bytes in readBuffer
					S = new String(readBuffer, "UTF-8"); //convert bytes stored in readBuffer to String
					textArea.append(S + "\n"); // Prints 'S' to the terminal
					
					int a = S.indexOf(":"); //Gets the index of ':' in String 'S'
					
					if(a != -1){ //If ':' is in the String S (meaning that user input has been prompted)
						
						ButNext.setEnabled(true); //buttons are enabled
						if(CounterCycle != 0) {
							ButEnd.setEnabled(true);
						}
						
						while((NextState == false) && (EndState == false)) { //While no button has been pressed (this while loops freezes the program until user input
							
							ButNext.addActionListener(new ActionListener() { //ActionListener for Next button
								public void actionPerformed(ActionEvent e) {
									NextState = true;
		
								}
							});
							
							ButEnd.addActionListener(new ActionListener() { //ActionListener for End button
								public void actionPerformed(ActionEvent e) {
									EndState = true;

								}
							});
						}
						
						ButNext.setEnabled(false); //Buttons are disabled after they have been pushed
						ButEnd.setEnabled(false);
						
						//If there has been 50 cycles then the program ends.
						if(CounterCycle == 50) {
							EndState = true; //This statement makes the loop end
							NextState = false;
							textArea.append("	Limit of cycles has been reached\n");
						}

						//If End button has been pushed
						if(EndState == true){
							byte[] WriteByte = new byte[1]; //Byte to write to the Serial Monitor
							WriteByte[0] = 57; //send 9 to end the program (9 is the argument that will trigger the end of the program in Arduino)
							MySerialPort.writeBytes(WriteByte,1); //Method to write element
							
							TimeUnit.SECONDS.sleep(1); //Wait that the Serial Monitor prints the final data
							ENDLOOP = false; //Stop the loop
						}
						
						
						if(NextState == true){//SEND a byte so that Arduino thinks that enter was pressed, so that the Arduino program runs
							byte[] WriteByte = new byte[1];
							WriteByte[0] = 65; //write an element to the serial monitor, so that Arduino program continues running
							MySerialPort.writeBytes(WriteByte,1);
							
							a = -1; //Resets the condition for next if statement.
							CounterCycle++; //The varibale that stores the number of cycle increases		
						}
					}
				}
					
			} catch (Exception e){ //Catch for try 
				 e.printStackTrace(); 
			}
	    
	}
	
	public static void GetData(){
		
		try{ //Try to get the results from the Serial monitor
			byte[] readBuffer1 = new byte[1000];//Create a byte to retrieve the data
			int numRead1 = MySerialPort.readBytes(readBuffer1, readBuffer1.length);
			Results = new String(readBuffer1, "UTF-8"); //convert bytes to String
		
		} catch (Exception e) {
			e.printStackTrace(); 
		}
		
        MySerialPort.flushIOBuffers();
        MySerialPort.closePort(); //close the Serial port
	
		//***Split 'Results' and store it in arrays 
		
		//Get the indexes of characters in the String to split the strings into multiple subStrings
		int P1 = Results.indexOf("s");
		int P2 = Results.indexOf("f");
		int P3 = Results.indexOf("|");
		int P4 = Results.indexOf("?");
		
		//Create a substring from Results//FILE refers to the variable that stores the name of the database inputted by user

		String TempPres = Results.substring(P1+1, P2-3); 
		String TempDif = Results.substring(P2+1, P3-1); 
		String TempVolume = Results.substring(P3+4, P4-1);
		
		//Store measurements in the arrays based on the substrings
		SPress = TempPres.split(" ");
		SDi = TempDif.split(" ");
		SVo = TempVolume.split(" ");
		
		textArea.append("Data was successfully imported to Java");
		GDM.dispose();
		System.out.println("GDM Disposed");
		SaveData sd = new SaveData(); //Create a new object of SaveData that will querry the data to a database 
	}
}
